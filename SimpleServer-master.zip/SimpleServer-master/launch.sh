#!/bin/sh
java -Xmx256m -Xms32m -jar SimpleServer.jar

echo Press Enter to continue
read nothing
